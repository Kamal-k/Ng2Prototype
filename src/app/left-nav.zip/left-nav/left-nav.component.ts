import { Component, OnInit } from '@angular/core';
import { LeftNavService } from './left-nav.service';

@Component({
  selector: 'app-left-nav',
  templateUrl: './left-nav.component.html',
  styleUrls: ['./left-nav.component.css'],
  providers: [LeftNavService]
})
export class LeftNavComponent implements OnInit {

  constructor(private leftnavSvc:LeftNavService) { 
    this.getMenus();
  }

  generalMenus:any
  liveMenus:any
  bottomMenus:any
  branding:any
  getMenus(){
    this.leftnavSvc.getMenus()
    .subscribe(res=>{
      console.log(res.generalMenus.childrenMenus);
      this.generalMenus=res.generalMenus;
      this.liveMenus=res.liveMenus;
      this.bottomMenus=res.bottomMenus;
      console.log(res.branding);
      this.branding=res.branding;
    })
  }

  offersCount = 0;
    increment(data){
        this.offersCount++;
    }

  ngOnInit() {
  }

}
